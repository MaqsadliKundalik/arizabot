from aiogram.fsm.state import State, StatesGroup

class ArizaStates(StatesGroup):
    ism = State()
    familiya = State()
    telefon = State()
    viloyat = State()
    tuman = State()
    more = State()
