from aiogram import Bot, Dispatcher
from config import token
from asyncio import run
from logging import basicConfig, INFO
import message, callback_data

dp = Dispatcher()

async def main():
    bot = Bot(token=token)
    dp.include_router(message.router)
    dp.include_router(callback_data.router)
    basicConfig(level=INFO)
    await dp.start_polling(bot)

run(main())