from aiogram.types import CallbackQuery
from aiogram.fsm.context import FSMContext
from viloyat import get_districts_region, get_district, get_region
from keyboards.inline import regions_markup, distircts_markup
from states import ArizaStates

async def regions_answer(call: CallbackQuery, state: FSMContext):
    vil_id = call.data.split(":")[1]
    await state.update_data(viloyat=vil_id)
    districts = get_districts_region(vil_id)
    markup = distircts_markup(districts=districts)
    await call.message.answer("Tumaningizni tanlang.", reply_markup=markup)
    await call.message.delete()

async def district_answer(call: CallbackQuery, state: FSMContext):
    dis_id = call.data.split(":")[1]
    await state.update_data(tuman=dis_id)
    await call.message.answer("Qo'shimcha nimadir yozing.")
    await state.set_state(ArizaStates.more)
    await call.message.delete()