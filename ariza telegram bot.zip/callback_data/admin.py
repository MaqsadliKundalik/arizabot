from aiogram import Bot
from aiogram.types import CallbackQuery

async def cnfm_answer(call: CallbackQuery, bot: Bot):
    user_id = call.data.split(":")[1]
    await bot.send_message(user_id, "✅ Arizangiz tasdiqlandi!")
    await call.answer("✅ Ariza tasdiqlandi!", show_alert=True)