from aiogram import Router, F
from . import register, admin

router = Router()
router.callback_query.register(register.regions_answer, F.data.startswith("vil:"))
router.callback_query.register(register.district_answer, F.data.startswith("dis:"))
router.callback_query.register(admin.cnfm_answer, F.data.startswith("cnfm"))
