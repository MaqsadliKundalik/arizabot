from aiogram import Router, F
from aiogram.filters import Command, and_f
from . import register, start, admin
from states import ArizaStates
from filters import IsAdmin

router = Router()
router.message.register(admin.start_command_answer, and_f(IsAdmin(), Command("start")))
router.message.register(start.start_command_answer, Command("start"))
router.message.register(register.get_first_name_answer, ArizaStates.ism)
router.message.register(register.get_last_name_answer, ArizaStates.familiya)
router.message.register(register.get_phone_answer, ArizaStates.telefon)
router.message.register(register.get_more_answer, ArizaStates.more)
router.message.register(register.ariza_answer, F.text == "Ariza berish")
