from aiogram.types import Message


async def start_command_answer(message: Message):
    await message.answer("Assalomu alaykum, xo'jayin!")
