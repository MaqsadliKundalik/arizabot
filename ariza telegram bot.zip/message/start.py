from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from keyboards.reply import main_menu


async def start_command_answer(message: Message, state: FSMContext):
    await message.answer("Xush kelibsiz!", reply_markup=main_menu)
    await state.clear()
