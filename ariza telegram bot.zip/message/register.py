from aiogram import Bot
from aiogram.types import Message, ReplyKeyboardRemove
from viloyat import get_district, get_districts, get_districts_region, get_regions, get_region
from aiogram.fsm.context import FSMContext
from keyboards.inline import regions_markup, distircts_markup, confirm_markup
from viloyat import get_region, get_regions, get_districts, get_district
from keyboards.reply import contact_menu, main_menu
from config import admin
from states import ArizaStates

async def ariza_answer(message: Message, state: FSMContext):
    await message.answer("Ismingizni kiriting", reply_markup=ReplyKeyboardRemove())
    await state.set_state(ArizaStates.ism)

async def get_first_name_answer(message: Message, state: FSMContext):
    await state.update_data(ism=message.text)
    await message.answer("Familyangizni kiriting.")
    await state.set_state(ArizaStates.familiya)

async def get_last_name_answer(message:Message, state: FSMContext):
    await state.update_data(familiya=message.text)
    await message.answer("Telefonr raqamingizni kirting.", reply_markup=contact_menu)
    await state.set_state(ArizaStates.telefon)

async def get_phone_answer(message: Message, state: FSMContext):
    if message.contact:
        if message.contact.user_id == message.from_user.id:
            await state.update_data(phone=message.contact.phone_number)
            markup = regions_markup(get_regions())
            await message.answer("Viloyatingiizni tanlang.", reply_markup=markup)
            await state.set_state(ArizaStates.viloyat)
        else:
            await message.answer("Menga o'zingizning telefon raqamongizni yuboring.")
    else:
        await message.answer("Pastdagi tugmaga bosib telefon raqamingizni yuboring.", reply_markup=contact_menu)

async def get_more_answer(message: Message, state: FSMContext, bot: Bot):
    context = await state.get_data()
    more = message.text
    ism = context.get("ism")
    familiya = context.get("familiya")
    telefon = context.get("phone")
    vil_id, dis_id = context.get("viloyat"), context.get("tuman")
    viloyat = get_region(vil_id)[0]["name_uz"]
    tuman = get_district(dis_id)[0]["name_uz"]
    text = F"""
🆕 YANGI ARIZA!
ism: {ism}
familiya: {familiya}
Telefon {telefon if telefon[0] == "+" else "+" + telefon}
Viloyat: {viloyat}
Tumani: {tuman}
Qo'shimcha: {more}
"""
    markup = confirm_markup(message.from_user.id)
    await bot.send_message(admin, text, reply_markup=markup)
    await message.answer("⏳ Arizangiz ko'rib chiqilmoqda...", reply_markup=main_menu)
    await state.clear()