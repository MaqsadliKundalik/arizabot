from json import load

def get_regions():
    with open("regions/regions.json") as regions_json:
        regions_data = load(regions_json)
        return regions_data

def get_region(id):
    region = [i for i in get_regions() if i["id"] == id]
    return region

def get_districts():
    with open("regions/districts.json") as districts_json:
        districts_data = load(districts_json)
        return districts_data

def get_districts_region(id):
    districts = [i for i in get_districts() if i["region_id"] == id]
    return districts

def get_district(district_id):
    district = [i for i in get_districts() if i["id"] == district_id]
    return district
