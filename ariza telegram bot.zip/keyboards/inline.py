from aiogram.utils.keyboard import InlineKeyboardBuilder

def regions_markup(regions):
    markup = InlineKeyboardBuilder()
    for region in regions:
        markup.button(text=region['name_uz'], callback_data=f"vil:{region['id']}")
    markup.adjust(1)
    return markup.as_markup()

def distircts_markup(districts):
    markup = InlineKeyboardBuilder()
    for district in districts:
        markup.button(text=district['name_uz'], callback_data=f"dis:{district['id']}")
    markup.adjust(1)
    return markup.as_markup()

def confirm_markup(user_id):
    markup = InlineKeyboardBuilder()
    markup.button(text="✅ Tasdiqlash", callback_data=f"cnfm:{user_id}")
    return markup.as_markup()
