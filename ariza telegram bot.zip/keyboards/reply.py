from aiogram.utils.keyboard import ReplyKeyboardBuilder

main_menu = ReplyKeyboardBuilder()
main_menu.button(text="Ariza berish")
main_menu = main_menu.as_markup()
main_menu.resize_keyboard = True
main_menu.is_persistent = True

contact_menu = ReplyKeyboardBuilder()
contact_menu.button(text="Telefon raqam yuborish", request_contact=True)
contact_menu = contact_menu.as_markup()
contact_menu.resize_keyboard = True
contact_menu.is_persistent = True